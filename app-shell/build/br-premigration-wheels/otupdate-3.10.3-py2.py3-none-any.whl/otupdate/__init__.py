"""
 Opentrons Update Server

This is a python application that serves HTTP requests to update the Opentrons
OT2 it is running on. It should not be run (except for testing purposes)
outside of an OT2 robot.
"""

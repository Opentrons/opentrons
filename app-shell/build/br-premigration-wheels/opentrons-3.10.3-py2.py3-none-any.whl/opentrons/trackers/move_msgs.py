from collections import namedtuple

new_pos_msg = namedtuple('new_pos_msg', 'moved_object x y z')

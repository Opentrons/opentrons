from opentrons.drivers.temp_deck.driver import TempDeck

__all__ = [
    'TempDeck'
]

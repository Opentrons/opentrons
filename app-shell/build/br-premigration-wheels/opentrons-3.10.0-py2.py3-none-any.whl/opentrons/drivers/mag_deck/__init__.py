from opentrons.drivers.mag_deck.driver import MagDeck

__all__ = [
    'MagDeck'
]

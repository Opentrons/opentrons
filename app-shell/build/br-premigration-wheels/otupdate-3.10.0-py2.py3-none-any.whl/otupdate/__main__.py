from .balena import __main__ as balena_main

balena_main.main()

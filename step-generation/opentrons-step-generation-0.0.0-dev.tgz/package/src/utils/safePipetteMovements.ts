import {
  ALL,
  COLUMN,
  FLEX_ROBOT_TYPE,
  getAddressableAreaFromSlotId,
  getDeckDefFromRobotType,
  getFlexSurroundingSlots,
  getModuleDef,
  getOt2SurroundingSlots,
  getPositionFromSlotId,
  getRobotDefFromRobotType,
  OT2_ROBOT_TYPE,
  SINGLE,
  THERMOCYCLER_MODULE_TYPE,
  THERMOCYCLER_MODULE_V2,
} from '@opentrons/shared-data'

import { EMPTY, OT2_TC_SLOTS } from '../constants'
import { getFullStackFromLabwares, getSlotInLocationStack } from './misc'

import type {
  AddressableArea,
  CoordinateTuple,
  LabwareDefinition,
  ModuleModel,
  NozzleConfigurationStyle,
  OT2AddressableAreaName,
  PipetteChannels,
  PipetteV2Specs,
  RobotType,
} from '@opentrons/shared-data'
import type {
  InvariantContext,
  LabwareEntity,
  ModuleEntities,
  PipetteEntity,
  RobotState,
  TipState,
} from '../types'

export const PRIMARY_NOZZLE = 'A12'
const FLEX_TC_LID_COLLISION_ZONE = {
  back_left: { x: -43.25, y: 454.9, z: 211.91 },
  front_right: { x: 128.75, y: 402, z: 211.91 },
}
const FLEX_TC_LID_BACK_LEFT_PT = {
  x: FLEX_TC_LID_COLLISION_ZONE.back_left.x,
  y: FLEX_TC_LID_COLLISION_ZONE.back_left.y,
  z: FLEX_TC_LID_COLLISION_ZONE.back_left.z,
}

const FLEX_TC_LID_FRONT_RIGHT_PT = {
  x: FLEX_TC_LID_COLLISION_ZONE.front_right.x,
  y: FLEX_TC_LID_COLLISION_ZONE.front_right.y,
  z: FLEX_TC_LID_COLLISION_ZONE.front_right.z,
}

interface SlotInfo {
  addressableArea: AddressableArea | null
  position: CoordinateTuple | null
}
export interface Point {
  x: number
  y: number
  z?: number
}

// return pipette bounds at a sepcific position
// note that this calculation is pessimistic to mirror behavior on protocol engine
// the returned plane is defined by the z-height of the empty nozzles (lowest case scenario)
// and the x-y bounds defined by the outer-most bounds of the pipette
const getPipetteBoundsAtSpecifiedMoveToPosition = (
  pipetteEntity: PipetteEntity,
  tipLength: number,
  wellTargetPoint: Point,
  primaryNozzle: string,
  tipOverlapOnNozzle: number
): Point[] => {
  const { nozzleMap, nozzleOffset, pipetteBoundingBoxOffsets } =
    pipetteEntity.spec
  const primaryNozzlePoint =
    nozzleMap == null || primaryNozzle == null
      ? nozzleOffset
      : nozzleMap[primaryNozzle]
  const pipetteBoundingBoxLeftXOffset =
    pipetteBoundingBoxOffsets.backLeftCorner[0]
  const pipetteBoundingBoxRightXOffset =
    pipetteBoundingBoxOffsets.frontRightCorner[0]
  const pipetteBoundingBoxBackYOffset =
    pipetteBoundingBoxOffsets.backLeftCorner[1]
  const pipetteBoundingBoxFrontYOffset =
    pipetteBoundingBoxOffsets.frontRightCorner[1]
  const leftX =
    wellTargetPoint.x - (primaryNozzlePoint[0] - pipetteBoundingBoxLeftXOffset)
  const rightX =
    wellTargetPoint.x + (pipetteBoundingBoxRightXOffset - primaryNozzlePoint[0])
  const backY =
    wellTargetPoint.y + (pipetteBoundingBoxBackYOffset - primaryNozzlePoint[1])
  const frontY =
    wellTargetPoint.y - (primaryNozzlePoint[1] - pipetteBoundingBoxFrontYOffset)

  const zNozzles = (wellTargetPoint.z ?? 0) + tipLength - tipOverlapOnNozzle

  const backLeftBound = { x: leftX, y: backY, z: zNozzles }
  const frontRightBound = { x: rightX, y: frontY, z: zNozzles }
  const backRightBound = { x: rightX, y: backY, z: zNozzles }
  const frontLeftBound = { x: leftX, y: frontY, z: zNozzles }
  return [backLeftBound, frontRightBound, backRightBound, frontLeftBound]
}

//  return whether the two provided rectangles are overlapping in the 2d space.
const getHasOverlappingRectangles = (
  rectangle1: Point[],
  rectangle2: Point[]
): boolean => {
  const oneLeftOfTwo = rectangle1[1].x < rectangle2[0].x
  const oneRightOfTwo = rectangle1[0].x > rectangle2[1].x
  const oneUnderTwo = rectangle1[0].y < rectangle2[1].y
  const oneOverTwo = rectangle1[1].y > rectangle2[0].y

  return !(oneLeftOfTwo || oneRightOfTwo || oneUnderTwo || oneOverTwo)
}

const getModuleHeightFromDeckDefinition = (
  moduleModel: ModuleModel,
  robotType: RobotType
): number => {
  if (robotType === FLEX_ROBOT_TYPE) {
    const deckDef = getDeckDefFromRobotType(robotType)
    const { addressableAreas } = deckDef.locations
    const moduleAddressableArea = addressableAreas.find(addressableArea =>
      addressableArea.id.includes(moduleModel)
    )
    return moduleAddressableArea?.offsetFromCutoutFixture[2] ?? 0
  }
  // OT-2
  return getModuleDef(moduleModel).dimensions.bareOverallHeight
}

//  check the highest Z-point of all items stacked given a deck slot (including modules,
//  adapters, and modules on adapters)
const getHighestZInSlot = (
  robotState: RobotState,
  invariantContext: InvariantContext,
  slotId: string,
  robotType: RobotType
): number => {
  const { modules, labware } = robotState
  const { moduleEntities, labwareEntities } = invariantContext

  let totalHeight: number = 0
  const largestLabwareStack = getFullStackFromLabwares(labware, slotId)
  const moduleInSlot = Object.keys(modules).find(
    moduleId => modules[moduleId].slot === slotId
  )

  //  if slot has labware, includes labware, adapters, and module
  if (largestLabwareStack.length > 0) {
    largestLabwareStack.forEach(item => {
      if (modules[item] != null) {
        totalHeight += getModuleHeightFromDeckDefinition(
          moduleEntities[item].model,
          robotType
        )
      }
      if (labware[item] != null) {
        totalHeight += labwareEntities[item].def.dimensions.zDimension
      }
    })
    // if slot only has module
  } else if (moduleInSlot != null) {
    totalHeight += getModuleHeightFromDeckDefinition(
      moduleEntities[moduleInSlot].model,
      robotType
    )
  }
  return totalHeight
}

//  check if the slot overlaps with the pipette position
const getSlotHasPotentialCollidingObject = (
  pipetteBounds: Point[],
  slotInfo: SlotInfo[],
  robotState: RobotState,
  invariantContext: InvariantContext,
  robotType: RobotType
): boolean => {
  const isThermocyclerOnDeck = Object.values(
    invariantContext.moduleEntities
  ).some(({ type }) => type === THERMOCYCLER_MODULE_TYPE)
  for (const slot of slotInfo) {
    const slotBounds = slot.addressableArea?.boundingBox
    const slotPosition = slot.position

    // explicit OT-2 check for if the pipette will enter the space above a thermocycler-occupied slot
    const willCollideWithThermocycler =
      isThermocyclerOnDeck &&
      robotType === OT2_ROBOT_TYPE &&
      slot.addressableArea?.id != null &&
      OT2_TC_SLOTS.includes(slot.addressableArea.id as OT2AddressableAreaName)

    if (willCollideWithThermocycler) {
      return true
    }

    // If slotPosition or slotBounds is null, continue to the next iteration
    if (slotPosition == null || slotBounds == null) {
      continue
    }

    const backLeftCoords = {
      x: slotPosition[0],
      y: slotBounds.yDimension + slotPosition[1],
      z: slotPosition[2],
    }
    const frontRightCoords = {
      x: slotPosition[0] + slotBounds.xDimension,
      y: slotPosition[1],
      z: slotPosition[2],
    }
    // Check for overlapping rectangles and pipette z-coordinate if slot overlaps with pipette bounds
    if (
      getHasOverlappingRectangles(
        [pipetteBounds[0], pipetteBounds[1]],
        [backLeftCoords, frontRightCoords]
      ) &&
      pipetteBounds[0].z != null
    ) {
      const highestZInSurroundingSlot =
        slot.addressableArea?.id != null
          ? getHighestZInSlot(
              robotState,
              invariantContext,
              slot.addressableArea.id,
              robotType
            )
          : 0
      if (highestZInSurroundingSlot >= pipetteBounds[0]?.z) {
        return true
      }
    }
  }
  return false
}

const getWillCollideWithThermocyclerLid = (
  pipetteBounds: Point[],
  moduleEntities: ModuleEntities
): boolean => {
  if (
    Object.values(moduleEntities).find(
      module => module.type === THERMOCYCLER_MODULE_TYPE
    )
  ) {
    return (
      getHasOverlappingRectangles(
        [FLEX_TC_LID_BACK_LEFT_PT, FLEX_TC_LID_FRONT_RIGHT_PT],
        [pipetteBounds[0], pipetteBounds[1]]
      ) && pipetteBounds[0].x <= FLEX_TC_LID_BACK_LEFT_PT.z
    )
  } else {
    return false
  }
}

const getWellPosition = (
  labwareEntity: LabwareEntity,
  wellName: string,
  wellLocationOffset: Point,
  addressableAreaOffset: CoordinateTuple,
  hasTip: boolean
): Point => {
  const { wells } = labwareEntity.def
  //  getting location from the bottom of the well since PD only supports aspirate/dispense from bottom
  //  note: api includes calibration data here which PD does not have knowledge of at the moment
  const wellDef = wells[wellName]
  return {
    x: wellDef.x + wellLocationOffset.x + (addressableAreaOffset?.[0] ?? 0),
    y: wellDef.y + wellLocationOffset.y + (addressableAreaOffset?.[1] ?? 0),
    z: hasTip
      ? wellDef.z +
        (wellLocationOffset.z ?? 0) +
        (addressableAreaOffset?.[2] ?? 0)
      : labwareEntity.def.dimensions.zDimension,
  }
}

//  util to use in step-generation for if the pipette movement is safe
export const getIsSafePipetteMovement = (args: {
  robotState: RobotState
  invariantContext: InvariantContext
  pipetteId: string
  labwareId: string
  wellLocationOffset?: Point
  wellTargetName?: string
  primaryNozzle?: string
  nozzleConfiguration?: NozzleConfigurationStyle
}): boolean => {
  const {
    robotState,
    invariantContext,
    pipetteId,
    labwareId,
    wellLocationOffset = { x: 0, y: 0, z: 0 },
    wellTargetName,
    primaryNozzle: primaryNozzleOverride,
    nozzleConfiguration: nozzleConfigurationOverride,
  } = args
  const {
    pipetteEntities,
    labwareEntities,
    stagingAreaEntities,
    moduleEntities,
  } = invariantContext
  const { labware: labwareState, tipState } = robotState

  const pipetteEntity = pipetteEntities[pipetteId]
  const nozzleConfiguration =
    nozzleConfigurationOverride ?? robotState.pipettes[pipetteId]?.nozzles
  const { spec: pipetteSpecs } = pipetteEntity ?? {}

  // NOTE: I don't like this, but step-generation is currently blind to robot type, so we'll infer from the pipette specs
  const displayCategory = pipetteSpecs?.displayCategory
  const isFlexPipette = displayCategory === 'FLEX'
  const robotType = isFlexPipette ? FLEX_ROBOT_TYPE : OT2_ROBOT_TYPE
  const deckDefinition = getDeckDefFromRobotType(robotType)

  //  early exit if labwareId is a trashBin or wasteChute or if no nozzle is provided
  if (
    labwareEntities[labwareId] == null ||
    wellTargetName == null ||
    nozzleConfiguration == null ||
    nozzleConfiguration === ALL
  ) {
    return true
  }

  const tiprackId = tipState.pipettes[pipetteId]?.tiprackURI
  const tiprackEntity = tiprackId != null ? labwareEntities[tiprackId] : null
  const tiprackTipLength =
    tiprackEntity != null ? tiprackEntity.def.parameters.tipLength : 0
  const stagingAreaSlots = Object.values(stagingAreaEntities).map(
    stagingArea => stagingArea.location as string
  )
  const pipetteHasTip = tipState.pipettes[pipetteId]?.hasTip ?? false
  // account for tip length if picking up tip
  const tipLength = pipetteHasTip ? (tiprackTipLength ?? 0) : 0
  const labwareSlot = getSlotInLocationStack(labwareState[labwareId].stack)
  const addressableAreaOffset = getPositionFromSlotId(
    labwareSlot,
    deckDefinition
  ) ?? [0, 0, 0]
  const isOnFlexThermocycler =
    robotType === FLEX_ROBOT_TYPE &&
    labwareState[labwareId].stack.some(
      item => moduleEntities[item]?.type === THERMOCYCLER_MODULE_TYPE
    )
  const thermocyclerOffset = isOnFlexThermocycler
    ? (deckDefinition.locations.addressableAreas.find(
        addressableArea => addressableArea.id === THERMOCYCLER_MODULE_V2
      )?.offsetFromCutoutFixture ?? [0, 0, 0])
    : [0, 0, 0]
  const fullOffset = [
    thermocyclerOffset[0] + addressableAreaOffset[0],
    thermocyclerOffset[1] + addressableAreaOffset[1],
    thermocyclerOffset[2] + addressableAreaOffset[2],
  ]
  const wellTargetPoint = getWellPosition(
    labwareEntities[labwareId],
    wellTargetName,
    wellLocationOffset,
    fullOffset as CoordinateTuple,
    pipetteHasTip
  )

  const { channels } = pipetteEntity.spec
  const primaryNozzle =
    primaryNozzleOverride ??
    getDefaultPrimaryNozzle({
      nozzles: nozzleConfiguration,
      channels,
    })

  const tipOverlapOnNozzle =
    tiprackEntity != null
      ? getTipOverlap({
          pipetteSpecs,
          tiprackUri: tiprackEntity.labwareDefURI,
          nozzles: nozzleConfiguration,
        })
      : 0
  const pipetteBoundsAtWellLocation = getPipetteBoundsAtSpecifiedMoveToPosition(
    pipetteEntity,
    tipLength,
    wellTargetPoint,
    primaryNozzle,
    tipOverlapOnNozzle
  )
  const isWithinPipetteExtents = getIsMovementWithinDeckExtents({
    channels,
    boundingBox: pipetteBoundsAtWellLocation,
    robotType,
  })
  if (!isWithinPipetteExtents) {
    return false
  }
  const surroundingSlots =
    robotType === OT2_ROBOT_TYPE
      ? getOt2SurroundingSlots(labwareSlot as OT2AddressableAreaName)
      : getFlexSurroundingSlots(labwareSlot, stagingAreaSlots)
  const slotInfos: SlotInfo[] = surroundingSlots.map(slot => {
    const addressableArea = getAddressableAreaFromSlotId(slot, deckDefinition)
    const position = getPositionFromSlotId(slot, deckDefinition)
    return {
      addressableArea,
      position,
    }
  })
  return (
    !getWillCollideWithThermocyclerLid(
      pipetteBoundsAtWellLocation,
      moduleEntities
    ) &&
    !getSlotHasPotentialCollidingObject(
      pipetteBoundsAtWellLocation,
      slotInfos,
      robotState,
      invariantContext,
      robotType
    )
  )
}

interface TipPickupAvailability {
  isSafe: boolean
  isComplete?: boolean
}

export const getIsSafePickupWithinTiprack = (args: {
  tipState: Record<string, TipState>
  primaryNozzle: string
  channels: PipetteChannels
  nozzleConfiguration: NozzleConfigurationStyle
  wellName: string
  tiprackDef: LabwareDefinition
  tipsToIgnore?: string[]
}): TipPickupAvailability => {
  const {
    tipState,
    primaryNozzle,
    channels,
    nozzleConfiguration,
    wellName,
    tiprackDef,
    tipsToIgnore = [],
  } = args
  const { ordering } = tiprackDef

  if (channels === 1) {
    return { isSafe: true, isComplete: tipState[wellName] !== EMPTY }
  }
  if (channels === 8) {
    const shouldReverse = primaryNozzle === 'H1'
    const columnIndex = getTipColumnIndex(wellName)
    const tipColumn = ordering[columnIndex]
    const tipColumnOrdered = shouldReverse
      ? [...tipColumn].reverse()
      : tipColumn
    if (nozzleConfiguration === SINGLE) {
      const targetWellIndex = tipColumnOrdered.indexOf(wellName)
      return {
        isSafe: tipColumnOrdered
          .slice(targetWellIndex + 1) // don't check the actual target well
          .every(
            well => tipState[well] === EMPTY || tipsToIgnore.includes(well)
          ),
        isComplete: tipState[wellName] !== EMPTY,
      }
    }
    // 8 channel pickup, full column
    return {
      isSafe: true,
      isComplete: tipColumnOrdered.every(well => tipState[well] !== EMPTY),
    }
  }

  // channels = 96, all nozzles configured
  if (nozzleConfiguration === ALL) {
    return {
      isSafe: true,
      isComplete: Object.keys(tiprackDef.wells).every(
        well => tipState[well] !== EMPTY
      ),
    }
  }
  // channels = 96, 8 nozzles configured
  if (nozzleConfiguration === COLUMN) {
    const shouldReverseColumns = primaryNozzle === 'A12'
    const columnIndex = getTipColumnIndex(wellName)
    const columnPreOrdering = ordering[columnIndex]
    const tipColumnsOrdered = shouldReverseColumns
      ? [...ordering].reverse()
      : ordering
    const targetColumnIndex = tipColumnsOrdered.indexOf(columnPreOrdering)
    return {
      isSafe: tipColumnsOrdered
        .slice(targetColumnIndex + 1) // don't check the actual target column
        .flat()
        .every(well => tipState[well] === EMPTY || tipsToIgnore.includes(well)),
      isComplete: tipColumnsOrdered[targetColumnIndex].every(
        well => tipState[well] !== EMPTY
      ),
    }
  }
  // channels = 96, 1 nozzle configured
  if (nozzleConfiguration === SINGLE) {
    const primaryRowName = getTipRowName(primaryNozzle)
    const primaryColumnName = getTipColumnName(primaryNozzle)
    const shouldReverseRows = primaryRowName === 'H'
    const shouldReverseColumns = primaryColumnName === '12'
    const tipColumnsOrdered = shouldReverseColumns
      ? [...ordering].reverse()
      : ordering
    const targetColumnIndex = tipColumnsOrdered.findIndex(column =>
      column.some(columnWell => columnWell === wellName)
    )

    return {
      isSafe: tipColumnsOrdered.slice(targetColumnIndex).every(column => {
        const columnOrdered = shouldReverseRows ? [...column].reverse() : column
        const rowIndex = columnOrdered.findIndex(
          colWell => getTipRowName(colWell) === getTipRowName(wellName)
        )
        return columnOrdered.slice(rowIndex).every(
          well =>
            tipState[well] === EMPTY ||
            tipsToIgnore.includes(well) ||
            // need to include the well's own row and column, so ignore its own tip state
            well === wellName
        )
      }),
      isComplete: tipState[wellName] !== EMPTY,
    }
  }

  // should not hit
  return { isSafe: false }
}

export const getTipRowName = (wellName: string): string => wellName.slice(0, 1)

export const getTipColumnName = (wellName: string): string => wellName.slice(1)

export const getTipColumnIndex = (wellName: string): number =>
  parseInt(wellName.slice(1)) - 1

export const getDefaultPrimaryNozzle = (args: {
  nozzles: NozzleConfigurationStyle
  channels: PipetteChannels
}): string => {
  const { nozzles, channels } = args
  if (channels === 8 && nozzles === SINGLE) {
    return 'H1'
  } else if (channels === 96) {
    if (nozzles === COLUMN) {
      return 'A12'
    } else if (nozzles === SINGLE) {
      return 'H12'
    }
  }
  return 'A1'
}

export const getTargetTipsFromWellSets = (args: {
  wellSets: string[][]
  nozzles: NozzleConfigurationStyle
  channels: PipetteChannels
  primaryNozzle: string
}): string[] => {
  const { wellSets, nozzles, channels, primaryNozzle } = args
  return wellSets.map(wellSet => {
    // 96-channel pipette with ALL nozzle configuration
    if (channels === 96 && nozzles === ALL) {
      return primaryNozzle
    }
    // 96- or 8-channel pipette with COLUMN nozzle configuration
    if (nozzles === COLUMN || (channels === 8 && nozzles === ALL)) {
      const shouldReverse = getTipRowName(primaryNozzle) === 'H'
      return shouldReverse ? wellSet[wellSet.length - 1] : wellSet[0]
    }
    // any pipette with SINGLE nozzle configuration
    console.assert(
      wellSet.length === 1,
      'Well set for SINGLE nozzle configuration should have exactly 1 well'
    )
    return wellSet[0]
  })
}

const getTipOverlap = (args: {
  pipetteSpecs: PipetteV2Specs
  tiprackUri: string
  nozzles: NozzleConfigurationStyle
}): number => {
  const { pipetteSpecs, tiprackUri, nozzles } = args
  const { channels } = pipetteSpecs
  const overlapKey = getOverlapKeyForPipetteSpecs(channels, nozzles)
  const tipOverlaps =
    pipetteSpecs.pickUpTipConfigurations.pressFit.configurationsByNozzleMap[
      overlapKey
    ]?.default.tipOverlaps

  // protect in case we get a bad overlap key
  if (tipOverlaps == null) {
    console.error(
      `No tip overlaps found for ${nozzles} and ${overlapKey} overlap.`
    )
    return 0
  }
  const maxVersion = Math.max(
    ...Object.keys(tipOverlaps).map(version => Number(version.slice(1)))
  )
  return (
    tipOverlaps[`v${maxVersion}`]?.[tiprackUri] ??
    tipOverlaps[`v${maxVersion}`]?.default ??
    0
  )
}

const getOverlapKeyForPipetteSpecs = (
  channels: PipetteChannels,
  nozzles: NozzleConfigurationStyle
): string => {
  if (channels === 1) {
    return 'SingleA1'
  }
  if (channels === 8) {
    return nozzles === SINGLE ? 'SingleH1' : 'Full'
  }
  if (channels === 96) {
    if (nozzles === SINGLE) {
      return 'SingleH12'
    } else if (nozzles === COLUMN) {
      return 'Column12'
    }
  }
  // default
  return 'Full'
}

const getIsMovementWithinDeckExtents = (args: {
  channels: PipetteChannels
  boundingBox: Point[]
  robotType: RobotType
}): boolean => {
  const { channels, boundingBox, robotType } = args
  const robotDef = getRobotDefFromRobotType(robotType)
  const { paddingOffsets } = robotDef
  const { front, rear, leftSide, rightSide } = paddingOffsets
  const [xExtent, yExtent] = robotDef.extents
  const [backLeftBound, frontRightBound] = boundingBox
  const { x: pipetteLeftBound, y: pipetteBackBound } = backLeftBound
  const { x: pipetteRightBound, y: pipetteFrontBound } = frontRightBound

  if (channels === 96) {
    // check left
    if (pipetteRightBound < leftSide) {
      return false
    }
    // check right
    const rightLimit = xExtent + rightSide
    if (pipetteLeftBound > rightLimit) {
      return false
    }
  }

  // 8- and 96-channel pipettes
  if (channels !== 1) {
    // check front
    if (pipetteBackBound < front) {
      return false
    }
    // check rear
    const rearLimit = yExtent + rear
    if (pipetteFrontBound > rearLimit) {
      return false
    }
  }
  return true
}

import { beforeEach, describe, expect, it } from 'vitest'

import {
  DEFAULT_PIPETTE,
  getErrorResult,
  getSuccessResult,
  makeContext,
  makeState,
  makeStateArgsStandard,
} from '../../../fixtures'
import { dropTip } from '../dropTip'

import type { InvariantContext, RobotState } from '../../../types'

const mockDropTipLocation = 'mockLocation'
describe('dropTip', () => {
  let invariantContext: InvariantContext
  beforeEach(() => {
    invariantContext = makeContext()
  })

  // TODO Ian 2019-04-19: this is a ONE-OFF fixture
  function makeRobotState(args: {
    singleHasTips: boolean
    multiHasTips: boolean
  }): RobotState {
    const _robotState = makeState({
      ...makeStateArgsStandard(),
      invariantContext,
      tiprackSetting: {
        tiprack1Id: true,
      },
    })

    _robotState.tipState.pipettes.p300SingleId = {
      hasTip: args.singleHasTips,
      tiprackURI: 'tiprackId',
    }
    _robotState.tipState.pipettes.p300MultiId = {
      hasTip: args.multiHasTips,
      tiprackURI: 'tiprackId',
    }
    return _robotState
  }

  describe('replaceTip: single channel', () => {
    it('drop tip if there is a tip', () => {
      const result = dropTip(
        {
          pipette: DEFAULT_PIPETTE,
          dropTipLocation: mockDropTipLocation,
          wellName: 'A1',
        },
        invariantContext,
        makeRobotState({
          singleHasTips: true,
          multiHasTips: true,
        })
      )
      const res = getSuccessResult(result)
      expect(res.commands).toEqual([
        {
          commandType: 'dropTip',
          key: expect.any(String),
          params: {
            pipetteId: DEFAULT_PIPETTE,
            labwareId: 'mockLocation',
            wellName: 'A1',
          },
        },
      ])
    })
    it('no tip on pipette, ignore dropTip', () => {
      const initialRobotState = makeRobotState({
        singleHasTips: false,
        multiHasTips: true,
      })
      const result = dropTip(
        {
          pipette: DEFAULT_PIPETTE,
          dropTipLocation: mockDropTipLocation,
        },
        invariantContext,
        initialRobotState
      )
      const res = getSuccessResult(result)
      expect(res.commands).toEqual([])
    })
  })
  describe('Multi-channel dropTip', () => {
    it('drop tip if there is a tip', () => {
      const result = dropTip(
        {
          pipette: 'p300MultiId',
          dropTipLocation: mockDropTipLocation,
          wellName: 'A1',
        },
        invariantContext,
        makeRobotState({
          singleHasTips: true,
          multiHasTips: true,
        })
      )
      const res = getSuccessResult(result)
      expect(res.commands).toEqual([
        {
          commandType: 'dropTip',
          key: expect.any(String),
          params: {
            pipetteId: 'p300MultiId',
            labwareId: 'mockLocation',
            wellName: 'A1',
          },
        },
      ])
    })
    it('no tip on pipette, ignore dropTip', () => {
      const initialRobotState = makeRobotState({
        singleHasTips: true,
        multiHasTips: false,
      })
      const result = dropTip(
        {
          pipette: 'p300MultiId',
          dropTipLocation: mockDropTipLocation,
        },
        invariantContext,
        initialRobotState
      )
      const res = getSuccessResult(result)
      expect(res.commands).toEqual([])
    })
  })

  describe('return tip', () => {
    it('returns tip if there is a tip', () => {
      const robotState = makeRobotState({
        singleHasTips: true,
        multiHasTips: true,
      })
      const robotStateForReturnTip = {
        ...robotState,
        pipettes: {
          ...robotState.pipettes,
          p300SingleId: {
            ...robotState.pipettes.p300SingleId,
            tipWell: 'A1',
            tiprackId: 'tiprack1Id',
          },
        },
      }
      const result = dropTip(
        {
          pipette: 'p300SingleId',
          isReturnTip: true,
        },
        invariantContext,
        robotStateForReturnTip
      )
      const res = getSuccessResult(result)
      expect(res.commands).toEqual([
        {
          commandType: 'dropTip',
          key: expect.any(String),
          params: {
            pipetteId: 'p300SingleId',
            labwareId: 'tiprack1Id',
            wellName: 'A1',
          },
        },
      ])
    })

    it('returns correct python if there is a tip', () => {
      const robotState = makeRobotState({
        singleHasTips: true,
        multiHasTips: true,
      })
      const robotStateForReturnTip = {
        ...robotState,
        pipettes: {
          ...robotState.pipettes,
          p300SingleId: {
            ...robotState.pipettes.p300SingleId,
            tipWell: 'A1',
            tiprackId: 'tiprack1Id',
          },
        },
      }
      const result = dropTip(
        {
          pipette: 'p300SingleId',
          isReturnTip: true,
        },
        invariantContext,
        robotStateForReturnTip
      )
      const res = getSuccessResult(result)
      expect(res.python).toEqual(
        'mock_pipette.drop_tip(location=mock_tip_rack_1["A1"])'
      )
    })

    it('raises error if most recent tip well is unknown', () => {
      const robotState = makeRobotState({
        singleHasTips: true,
        multiHasTips: true,
      })
      const robotStateForReturnTip = {
        ...robotState,
        pipettes: {
          ...robotState.pipettes,
          p300SingleId: {
            ...robotState.pipettes.p300SingleId,
            tiprackId: 'tiprack1Id',
          },
        },
      }

      const result = dropTip(
        {
          pipette: 'p300SingleId',
          isReturnTip: true,
        },
        invariantContext,
        robotStateForReturnTip
      )
      const res = getErrorResult(result)
      expect(res.errors[0].type).toEqual('RETURN_TIP_UNAVAILABLE')
    })

    it('raises error if most recent tip rack is unknown', () => {
      const robotState = makeRobotState({
        singleHasTips: true,
        multiHasTips: true,
      })
      const robotStateForReturnTip = {
        ...robotState,
        pipettes: {
          ...robotState.pipettes,
          p300SingleId: {
            ...robotState.pipettes.p300SingleId,
            tipWell: 'A1',
            tiprackId: undefined,
          },
        },
      }

      const result = dropTip(
        {
          pipette: 'p300SingleId',
          isReturnTip: true,
        },
        invariantContext,
        robotStateForReturnTip
      )
      const res = getErrorResult(result)
      expect(res.errors[0].type).toEqual('RETURN_TIP_UNAVAILABLE')
    })
  })
})
